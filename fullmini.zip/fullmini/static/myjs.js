
        $(document).ready(function () {
            get_posts('{{ user_info.username }}')
        })

        function sign_out() {
            $.cookie("mytoken", null, { path: '/'});
            alert('로그아웃!')
            window.location.href = "/login"
        }

        function delete_post(id) {
            $.ajax({
                type: "POST",
                url: "/delete_post",
                data: {
                    id_give: id
                },
                success: function (response) {
                    if (response["result"] == "success") {
                        alert(response["msg"])
                        window.location.reload()

                    }
                }
            });
        }

        function update_profile() {
            let name = $('#input-name').val()
            let file = $('#input-pic')[0].files[0]
            let about = $("#textarea-about").val()
            let form_data = new FormData()
            form_data.append("file_give", file)
            form_data.append("name_give", name)
            form_data.append("about_give", about)
            console.log(name, file, about, form_data)

            $.ajax({
                type: "POST",
                url: "/update_profile",
                data: form_data,
                cache: false,
                contentType: false,
                processData: false,
                success: function (response) {
                    if (response["result"] == "success") {
                        alert(response["msg"])
                        window.location.reload()

                    }
                }
            });
        }

        function get_posts(username) {
            if (username == undefined) {
                username = ""
            }
            $("#cards").empty()
            $.ajax({
                type: "GET",
                url: `/get_posts?username_give=${username}`,
                data: {},
                success: function (response) {
                    if (response["result"] == "success") {
                        let posts = response["posts"]
                        for (let i = 0; i < posts.length; i++) {
                            let post = posts[i]
                            let id = post["_id"]
                            console.log(id)
                            let html_temp = `<div class="card" id="${post["_id"]}">
                                                <div class="card-image">
                                                    <figure class="image is-4by3">
                                                        <img src="/static/${post['file_path']}" alt="Profile Image">
                                                    </figure>
                                                </div>
                                                <div class="card-content">
                                                    <div class="media">
                                                        <div class="media-left">
                                                            <figure class="image is-48x48">
                                                                <img src="/static/${post['profile_pic_real']}" alt="Image">
                                                            </figure>
                                                        </div>
                                                        <div class="media-content">
                                                            <p class="title is-5"> ${post['weather']} ${post['region']}</p>
                                                            <p class="subtitle is-6">${post['username']}</p>
                                                        </div>
                                                    </div>

                                                    <div class="content">
                                                        ${post['text']}
                                                        <p style="font-size: smaller; margin-top:1em" id="time">${post['showtime']}</p>
                                                    </div>
                                                    <div class="delete_button">
                                                        <a class="button level-item has-text-centered is-sparta is-outlined" aria-label="logout"
                                                           onclick="delete_post('${post["_id"]}')">삭제&nbsp&nbsp<span class="icon is-small">
                                                            <i class="fa-regular fa-trash-can"></i></span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>`

                            $("#cards").append(html_temp)
                        }
                    }
                }
            })
        }
